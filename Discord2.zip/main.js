var auth = require('./auth.json');
const Discord = require("discord.js");
const client = new Discord.Client();
var getJSON = require('get-json');

var DebugChannel = null;

client.on("ready", () => {
  console.log("I am ready!");
  //client.channels.get('411155617567211522').send('testing 1234, starting up');
//  DebugChannel = client.channels.get(auth.DebugChannel);
 // DebugChannel.send('Bot code starting up!');
  
});

client.on("message", async message => {
    try {
    if (message.content.startsWith("!")) {
        const args = message.content.trim().split(/ +/g);
        const command = args.shift().toLowerCase().slice(1,20);
        var st = "Bot_"+command;
        console.log(st);
        var module = require("./Commands/"+st+".js");
        module[st](message,args);
        }
    } catch (ex) {
        console.log(ex.message);
      //  DebugChannel.send('Exception in code: ' + ex.message);
      //  DebugChannel.send(ex.stack);
    }
});

if (1) {  //switch for what site we are on.......
    client.login(auth.CWToken);
    } else {
    client.login(auth.PonziedToken);
}




