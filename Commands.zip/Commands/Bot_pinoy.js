/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

//http://www.peppii.com/wp-content/uploads/2015/03/gay-pinoy-2.jpg


module.exports =
{
    Bot_pinoy : function(msg,arg) {
        msg.reply("http://www.peppii.com/wp-content/uploads/2015/03/gay-pinoy-2.jpg");
    }
};





