/* Bot_test.js
 */

module.exports =
{

    Bot_test : function(msg,arg) {
        msg.reply("Test worked!");
    }
};


